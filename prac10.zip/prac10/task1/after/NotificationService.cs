namespace after
{
    public abstract class NotificationService
    {
        public abstract void Send(string message);
    }
}