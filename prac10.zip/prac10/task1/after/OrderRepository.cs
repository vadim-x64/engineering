﻿namespace after
{
    public class OrderRepository
    {
        public void SaveToDb(string order)
        {
            Console.WriteLine("Збереження в базу даних.");
        }
    }
}