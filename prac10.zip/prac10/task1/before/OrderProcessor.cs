﻿namespace before
{
    public class OrderProcessor
    {
        public void ProcessOrder(string item)
        {
            Console.WriteLine("Збереження в базу даних.");
            Console.WriteLine("Відправлення листа підтвердження.");
        }
    }
}