namespace task3
{
    public abstract class Vehicle
    {
        public abstract void Start();
        public abstract void Stop();
    }
}